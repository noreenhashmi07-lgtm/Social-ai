// ─────────────────────────────────────────────────────
//  routes/auth.js
//  Handles OAuth login for each platform
// ─────────────────────────────────────────────────────
const express = require("express");
const router  = express.Router();
const axios   = require("axios");

// ── FACEBOOK / INSTAGRAM OAuth ───────────────────────
// Step 1: redirect user to Facebook login
router.get("/facebook", (req, res) => {
  const url = `https://www.facebook.com/v18.0/dialog/oauth?client_id=${process.env.META_APP_ID}&redirect_uri=${process.env.REDIRECT_URI}/auth/facebook/callback&scope=pages_manage_posts,instagram_basic,instagram_content_publish,pages_read_engagement`;
  res.redirect(url);
});

// Step 2: Facebook redirects back here with a code
router.get("/facebook/callback", async (req, res) => {
  const { code } = req.query;
  try {
    const { data } = await axios.get("https://graph.facebook.com/v18.0/oauth/access_token", {
      params: {
        client_id:     process.env.META_APP_ID,
        client_secret: process.env.META_APP_SECRET,
        redirect_uri:  `${process.env.REDIRECT_URI}/auth/facebook/callback`,
        code,
      },
    });
    // ✅ Save data.access_token to your database (Firebase Firestore)
    // For now we just return it — in production save to DB
    console.log("Facebook token:", data.access_token);
    res.json({ success: true, platform: "facebook", token: data.access_token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── LINKEDIN OAuth ────────────────────────────────────
router.get("/linkedin", (req, res) => {
  const url = `https://www.linkedin.com/oauth/v2/authorization?response_type=code&client_id=${process.env.LINKEDIN_CLIENT_ID}&redirect_uri=${encodeURIComponent(process.env.REDIRECT_URI + '/auth/linkedin/callback')}&scope=openid%20profile%20email%20w_member_social`;
  res.redirect(url);
});

router.get("/linkedin/callback", async (req, res) => {
  const { code } = req.query;
  try {
    const { data } = await axios.post("https://www.linkedin.com/oauth/v2/accessToken", null, {
      params: {
        grant_type:    "authorization_code",
        code,
        client_id:     process.env.LINKEDIN_CLIENT_ID,
        client_secret: process.env.LINKEDIN_CLIENT_SECRET,
        redirect_uri:  `${process.env.REDIRECT_URI}/auth/linkedin/callback`,
      },
    });
    // ✅ Save data.access_token to your database
    console.log("LinkedIn token:", data.access_token);
    res.json({ success: true, platform: "linkedin", token: data.access_token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GOOGLE / YOUTUBE OAuth ────────────────────────────
router.get("/youtube", (req, res) => {
  const url = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${process.env.GOOGLE_CLIENT_ID}&redirect_uri=${process.env.REDIRECT_URI}/auth/youtube/callback&response_type=code&scope=https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/youtube.readonly&access_type=offline`;
  res.redirect(url);
});

router.get("/youtube/callback", async (req, res) => {
  const { code } = req.query;
  try {
    const { data } = await axios.post("https://oauth2.googleapis.com/token", {
      code,
      client_id:     process.env.GOOGLE_CLIENT_ID,
      client_secret: process.env.GOOGLE_CLIENT_SECRET,
      redirect_uri:  `${process.env.REDIRECT_URI}/auth/youtube/callback`,
      grant_type:    "authorization_code",
    });
    // ✅ Save data.access_token + data.refresh_token to your database
    console.log("YouTube token:", data.access_token);
    res.json({ success: true, platform: "youtube", token: data.access_token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PINTEREST OAuth ───────────────────────────────────
router.get("/pinterest", (req, res) => {
  const url = `https://www.pinterest.com/oauth/?client_id=${process.env.PINTEREST_APP_ID}&redirect_uri=${process.env.REDIRECT_URI}/auth/pinterest/callback&response_type=code&scope=boards:read,pins:read,pins:write`;
  res.redirect(url);
});

router.get("/pinterest/callback", async (req, res) => {
  const { code } = req.query;
  try {
    const { data } = await axios.post("https://api.pinterest.com/v5/oauth/token",
      `grant_type=authorization_code&code=${code}&redirect_uri=${process.env.REDIRECT_URI}/auth/pinterest/callback`,
      {
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        auth: { username: process.env.PINTEREST_APP_ID, password: process.env.PINTEREST_APP_SECRET },
      }
    );
    console.log("Pinterest token:", data.access_token);
    res.json({ success: true, platform: "pinterest", token: data.access_token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── REDDIT OAuth ──────────────────────────────────────
router.get("/reddit", (req, res) => {
  const url = `https://www.reddit.com/api/v1/authorize?client_id=${process.env.REDDIT_CLIENT_ID}&response_type=code&state=random_string&redirect_uri=${process.env.REDIRECT_URI}/auth/reddit/callback&duration=permanent&scope=submit,read`;
  res.redirect(url);
});

router.get("/reddit/callback", async (req, res) => {
  const { code } = req.query;
  try {
    const { data } = await axios.post("https://www.reddit.com/api/v1/access_token",
      `grant_type=authorization_code&code=${code}&redirect_uri=${process.env.REDIRECT_URI}/auth/reddit/callback`,
      {
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        auth: { username: process.env.REDDIT_CLIENT_ID, password: process.env.REDDIT_CLIENT_SECRET },
      }
    );
    console.log("Reddit token:", data.access_token);
    res.json({ success: true, platform: "reddit", token: data.access_token });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
