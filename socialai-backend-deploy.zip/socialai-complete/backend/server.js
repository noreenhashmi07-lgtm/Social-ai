// ─────────────────────────────────────────────────────
//  SocialAI Backend — server.js
//  Run: node server.js
// ─────────────────────────────────────────────────────
const express    = require("express");
const cors       = require("cors");
const dotenv     = require("dotenv");

dotenv.config(); // loads your .env file automatically

const app  = express();
const PORT = process.env.PORT || 4000;

app.use(cors({ origin: "http://localhost:3000" })); // your React frontend
app.use(express.json());

// ── Route files ──────────────────────────────────────
const authRoutes      = require("./routes/auth");
const postsRoutes     = require("./routes/posts");
const analyticsRoutes = require("./routes/analytics");

app.use("/auth",      authRoutes);
app.use("/posts",     postsRoutes);
app.use("/analytics", analyticsRoutes);

// ── Health check ─────────────────────────────────────
app.get("/", (req, res) => {
  res.json({ status: "SocialAI backend running ✅" });
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
