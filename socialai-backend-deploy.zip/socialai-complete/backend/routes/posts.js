// ─────────────────────────────────────────────────────
//  routes/posts.js
//  Publish posts to each platform
// ─────────────────────────────────────────────────────
const express = require("express");
const router  = express.Router();
const axios   = require("axios");

// ── POST to Facebook Page ─────────────────────────────
// Body: { token, pageId, message }
router.post("/facebook", async (req, res) => {
  const { token, pageId, message } = req.body;
  try {
    const { data } = await axios.post(
      `https://graph.facebook.com/v18.0/${pageId}/feed`,
      { message, access_token: token }
    );
    res.json({ success: true, postId: data.id });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── POST to Instagram ─────────────────────────────────
// Instagram requires 2 steps: create container → publish
// Body: { token, igUserId, imageUrl, caption }
router.post("/instagram", async (req, res) => {
  const { token, igUserId, imageUrl, caption } = req.body;
  try {
    // Step 1: create media container
    const { data: container } = await axios.post(
      `https://graph.facebook.com/v18.0/${igUserId}/media`,
      { image_url: imageUrl, caption, access_token: token }
    );
    // Step 2: publish the container
    const { data: publish } = await axios.post(
      `https://graph.facebook.com/v18.0/${igUserId}/media_publish`,
      { creation_id: container.id, access_token: token }
    );
    res.json({ success: true, postId: publish.id });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── POST to LinkedIn ──────────────────────────────────
// Body: { token, personUrn, text }
// personUrn looks like "urn:li:person:XXXXXXX"
router.post("/linkedin", async (req, res) => {
  const { token, personUrn, text } = req.body;
  try {
    const { data } = await axios.post(
      "https://api.linkedin.com/v2/ugcPosts",
      {
        author: personUrn,
        lifecycleState: "PUBLISHED",
        specificContent: {
          "com.linkedin.ugc.ShareContent": {
            shareCommentary: { text },
            shareMediaCategory: "NONE",
          },
        },
        visibility: { "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC" },
      },
      { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
    );
    res.json({ success: true, postId: data.id });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── POST to Pinterest (create Pin) ───────────────────
// Body: { token, boardId, title, description, imageUrl, link }
router.post("/pinterest", async (req, res) => {
  const { token, boardId, title, description, imageUrl, link } = req.body;
  try {
    const { data } = await axios.post(
      "https://api.pinterest.com/v5/pins",
      {
        board_id: boardId,
        title,
        description,
        media_source: { source_type: "image_url", url: imageUrl },
        link,
      },
      { headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" } }
    );
    res.json({ success: true, pinId: data.id });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── POST to Reddit ────────────────────────────────────
// Body: { token, subreddit, title, text }
router.post("/reddit", async (req, res) => {
  const { token, subreddit, title, text } = req.body;
  try {
    const { data } = await axios.post(
      "https://oauth.reddit.com/api/submit",
      `kind=self&sr=${subreddit}&title=${encodeURIComponent(title)}&text=${encodeURIComponent(text)}`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "SocialAI/1.0",
        },
      }
    );
    res.json({ success: true, postId: data.json?.data?.name });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── YouTube: note ─────────────────────────────────────
// YouTube video upload requires multipart upload (large files)
// Use the googleapis npm package for this — see README
router.post("/youtube", async (req, res) => {
  res.json({ message: "YouTube upload requires googleapis package. See README.md for setup." });
});

module.exports = router;
