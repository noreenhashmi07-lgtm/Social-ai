// ─────────────────────────────────────────────────────
//  routes/analytics.js
//  Fetch stats from each platform
// ─────────────────────────────────────────────────────
const express = require("express");
const router  = express.Router();
const axios   = require("axios");

// ── Facebook Page analytics ───────────────────────────
// GET /analytics/facebook?token=xxx&pageId=xxx
router.get("/facebook", async (req, res) => {
  const { token, pageId } = req.query;
  try {
    const { data } = await axios.get(
      `https://graph.facebook.com/v18.0/${pageId}/insights`,
      { params: { metric: "page_impressions,page_engaged_users,page_fans", access_token: token } }
    );
    res.json({ success: true, data: data.data });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── Instagram analytics ───────────────────────────────
// GET /analytics/instagram?token=xxx&igUserId=xxx
router.get("/instagram", async (req, res) => {
  const { token, igUserId } = req.query;
  try {
    const { data } = await axios.get(
      `https://graph.facebook.com/v18.0/${igUserId}/insights`,
      { params: { metric: "impressions,reach,follower_count", period: "day", access_token: token } }
    );
    res.json({ success: true, data: data.data });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── LinkedIn analytics ────────────────────────────────
// GET /analytics/linkedin?token=xxx&personUrn=xxx
router.get("/linkedin", async (req, res) => {
  const { token, personUrn } = req.query;
  try {
    const { data } = await axios.get(
      `https://api.linkedin.com/v2/organizationalEntityShareStatistics?q=organizationalEntity&organizationalEntity=${encodeURIComponent(personUrn)}`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    res.json({ success: true, data: data.elements });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── YouTube analytics ─────────────────────────────────
// GET /analytics/youtube?token=xxx
router.get("/youtube", async (req, res) => {
  const { token } = req.query;
  try {
    const { data } = await axios.get(
      "https://www.googleapis.com/youtube/v3/channels",
      { params: { part: "statistics", mine: true, access_token: token } }
    );
    const stats = data.items?.[0]?.statistics;
    res.json({
      success: true,
      data: {
        subscribers: stats?.subscriberCount,
        views:       stats?.viewCount,
        videos:      stats?.videoCount,
      },
    });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── Pinterest analytics ───────────────────────────────
// GET /analytics/pinterest?token=xxx
router.get("/pinterest", async (req, res) => {
  const { token } = req.query;
  try {
    const today     = new Date().toISOString().split("T")[0];
    const lastMonth = new Date(Date.now() - 30*24*60*60*1000).toISOString().split("T")[0];
    const { data }  = await axios.get(
      "https://api.pinterest.com/v5/user_account/analytics",
      {
        params: { start_date: lastMonth, end_date: today, metric_types: "IMPRESSION,SAVE,PIN_CLICK" },
        headers: { Authorization: `Bearer ${token}` },
      }
    );
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

// ── Reddit (basic — karma & info) ────────────────────
// GET /analytics/reddit?token=xxx
router.get("/reddit", async (req, res) => {
  const { token } = req.query;
  try {
    const { data } = await axios.get(
      "https://oauth.reddit.com/api/v1/me",
      { headers: { Authorization: `Bearer ${token}`, "User-Agent": "SocialAI/1.0" } }
    );
    res.json({
      success: true,
      data: { karma: data.total_karma, name: data.name, icon: data.icon_img },
    });
  } catch (err) {
    res.status(500).json({ error: err.response?.data || err.message });
  }
});

module.exports = router;
